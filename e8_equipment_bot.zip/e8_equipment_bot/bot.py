"""
bot.py - E8 Section Equipment List Telegram bot

Commands:
  /start, /help        - usage instructions
  /loco <number>        - show every equipment detail recorded for a loco
  /make <text>           - find every loco/field where a make (e.g. AVENTAL,
                            BTIL, Medha, LAX, SOUTHCO...) or any other text
                            appears, across both sheets
  (plain message)        - convenience: a number is treated as /loco,
                            anything else as /make

Admin-only:
  Send a .xls/.xlsx file to the bot (from an ADMIN_CHAT_ID) to rebuild the
  database in place, so the bot always reflects the latest "AS ON <date>"
  equipment list without needing a redeploy.

Setup:
  1. pip install -r requirements.txt
  2. Create a bot with @BotFather on Telegram, copy the token it gives you.
  3. export TELEGRAM_BOT_TOKEN="8505829778:AAFDDG6CaFH7LBDYoeBilNLsLPg6Dcan9pQ"
     (optional) export ADMIN_CHAT_IDS="111111,222222"   # who may upload a
     replacement spreadsheet; leave unset to disable that feature.
  4. python build_db.py "E8_SECTION_EQUIPMENT_LIST_AS_ON_170826.xls" equipment.db
  5. python bot.py
"""

import os
import re
import html
import sqlite3
import logging
import tempfile
from collections import defaultdict, OrderedDict

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

import build_db

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("e8-equipment-bot")

DB_PATH = os.environ.get("EQUIPMENT_DB_PATH", "equipment.db")
XLS_PATH = os.environ.get("EQUIPMENT_XLS_PATH", "E8 QUIPMENTS LIST AS ON 170826.xls")
TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
ADMIN_CHAT_IDS = {
    x.strip() for x in os.environ.get("ADMIN_CHAT_IDS", "").split(",") if x.strip()
}

TABLES = ["3PHASE", "CONVENTIONAL"]
MAX_MESSAGE_CHARS = 3500  # keep comfortably under Telegram's 4096 limit


def get_conn():
    return sqlite3.connect(DB_PATH)


def table_labels(conn, table):
    cur = conn.cursor()
    rows = cur.execute(
        "SELECT column_name, display_label FROM column_labels WHERE table_name=? ORDER BY col_order",
        (table,),
    ).fetchall()
    return rows  # list[(col_name, display_label)]


def find_loco_column(labels):
    for col_name, display in labels:
        if display.strip().upper() in ("LOCO NO", "LOCO NO.", "LOCO_NO"):
            return col_name
    return None


def chunk_text(text, limit=MAX_MESSAGE_CHARS):
    lines = text.split("\n")
    chunks, cur = [], ""
    for line in lines:
        if len(cur) + len(line) + 1 > limit:
            chunks.append(cur)
            cur = ""
        cur += line + "\n"
    if cur:
        chunks.append(cur)
    return chunks


# Sub-field suffixes that build_db.py appends to an equipment group's name
# (longest first, so "MFG Date" matches before "MFG").
_FIELD_SUFFIXES = [
    "MFG Date", "S. No", "SL NO", "Model", "MFG", "Make", "MAKE",
    "Mfg", "MFY", "S.No", "S.NO", "Age", "AGE", "DOC",
]

_GROUP_ICONS = {
    "SPM": "⚙️", "PG": "🔌", "SR": "🔀", "BUR": "🔋", "VCU": "🖥️",
    "RTIS": "📡", "DPWCS": "🚨", "VCD": "🎚️", "FDCS": "🛡️", "SIV": "⚡",
    "MAKE": "🏭", "TYPE": "🏷️", "S.NO": "🔢", "LOCO NO": "🚂", "S.No": "🔢",
}


def split_group_field(label):
    """'SPM-1 Make' -> ('SPM-1', 'Make'); 'RTIS' -> ('RTIS', None)."""
    for suf in _FIELD_SUFFIXES:
        if label.endswith(" " + suf):
            return label[: -(len(suf) + 1)], suf
    m = re.match(r"^(.*) (#\d+)$", label)
    if m:
        return m.group(1), m.group(2)
    return label, None


def group_icon(group):
    key = re.sub(r"[\s\d\-&]+$", "", group).upper()
    for prefix, icon in _GROUP_ICONS.items():
        if key.startswith(prefix.upper()):
            return icon
    return "🔧"


def build_sections(labels, values):
    """Group a row's non-empty fields by equipment (SPM-1, PG, RTIS...)
    preserving column order, so the reply reads like the original sheet's
    layout instead of a flat list of fields."""
    sections = OrderedDict()
    for col_name, display in labels:
        v = values.get(col_name)
        if not v:
            continue
        group, field = split_group_field(display)
        sections.setdefault(group, []).append((field, v))
    return sections


def format_loco_block(table, labels, row, cols):
    values = dict(zip(cols, row))
    sections = build_sections(labels, values)
    lines = [f"📋 <b>{html.escape(table)}</b>"]
    for group, entries in sections.items():
        icon = group_icon(group)
        esc_group = html.escape(group)
        if len(entries) == 1 and entries[0][0] is None:
            _, v = entries[0]
            lines.append(f"{icon} <b>{esc_group}:</b> {html.escape(v)}")
        else:
            lines.append(f"{icon} <b>{esc_group}</b>")
            for field, v in entries:
                fname = html.escape(field) if field else "Value"
                lines.append(f"    • {fname}: {html.escape(v)}")
    return "\n".join(lines)


async def loco_lookup(update: Update, context: ContextTypes.DEFAULT_TYPE, loco_no: str):
    loco_no = loco_no.strip()
    conn = get_conn()
    found_any = False
    blocks = []
    for table in TABLES:
        try:
            labels = table_labels(conn, table)
        except sqlite3.OperationalError:
            continue
        loco_col = find_loco_column(labels)
        if not loco_col:
            continue
        cur = conn.cursor()
        cols = [d[0] for d in cur.execute(f'SELECT * FROM "{table}" LIMIT 1').description]
        rows = cur.execute(
            f'SELECT * FROM "{table}" WHERE "{loco_col}"=?', (loco_no,)
        ).fetchall()
        for row in rows:
            found_any = True
            blocks.append(format_loco_block(table, labels, row, cols))
    conn.close()

    if not found_any:
        await update.message.reply_text(
            f"❌ No record found for loco {loco_no}. Check the number and try again, "
            f"e.g. /loco 32747"
        )
        return

    text = f"🚂 <b>Loco {html.escape(loco_no)}</b> — equipment details\n\n" + "\n\n".join(blocks)
    for chunk in chunk_text(text):
        await update.message.reply_text(chunk, parse_mode=ParseMode.HTML)


async def make_lookup(update: Update, context: ContextTypes.DEFAULT_TYPE, query: str):
    query = query.strip()
    if not query:
        await update.message.reply_text("Usage: /make <text to search>, e.g. /make AVENTAL")
        return

    conn = get_conn()
    q = f"%{query.lower()}%"
    grouped = defaultdict(list)  # loco_no -> list of (table, field, value)
    total_hits = 0

    for table in TABLES:
        try:
            labels = table_labels(conn, table)
        except sqlite3.OperationalError:
            continue
        loco_col = find_loco_column(labels)
        if not loco_col:
            continue
        cur = conn.cursor()
        cols = [d[0] for d in cur.execute(f'SELECT * FROM "{table}" LIMIT 1').description]
        col_list_sql = ", ".join(f'lower("{c}") LIKE ?' for c in cols)
        where_sql = " OR ".join(f'lower("{c}") LIKE ?' for c in cols)
        params = [q] * len(cols)
        rows = cur.execute(f'SELECT * FROM "{table}" WHERE {where_sql}', params).fetchall()

        display = dict(labels)
        for row in rows:
            values = dict(zip(cols, row))
            loco_no = values.get(loco_col, "?")
            for col_name, val in values.items():
                if val and query.lower() in val.lower():
                    total_hits += 1
                    grouped[loco_no].append((table, display.get(col_name, col_name), val))
    conn.close()

    if not grouped:
        await update.message.reply_text(f"❌ No matches found for '{query}'.")
        return

    loco_numbers = [str(x) for x in grouped.keys()]

    lines = [f"🔍 <b>Matches for '{html.escape(query)}'</b> — {len(loco_numbers)} loco(s) found\n"]
    lines.append("📋 <b>Loco numbers:</b> " + ", ".join(html.escape(n) for n in loco_numbers))

    DETAIL_LIMIT = 20
    if len(grouped) <= DETAIL_LIMIT:
        lines.append("")  # blank line before detail section
        for loco_no, hits in grouped.items():
            lines.append(f"🚂 <b>Loco {html.escape(str(loco_no))}</b>")
            for table, field, val in hits:
                lines.append(f"    • [{html.escape(table)}] {html.escape(field)}: {html.escape(val)}")
    else:
        lines.append(
            f"\n💡 {len(grouped)} matches is a lot to detail here — use "
            f"<code>/loco &lt;number&gt;</code> on any of the above for full details, "
            f"or refine your search (e.g. '{html.escape(query)} V3') to narrow it down."
        )

    text = "\n".join(lines)
    for chunk in chunk_text(text):
        await update.message.reply_text(chunk, parse_mode=ParseMode.HTML)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🚂 <b>E8 Section Equipment List Bot</b>\n\n"
        "📌 <code>/loco &lt;number&gt;</code> — all equipment details for a loco\n"
        "    e.g. <code>/loco 32747</code>\n\n"
        "🔍 <code>/make &lt;text&gt;</code> — find locos by equipment make or any text\n"
        "    e.g. <code>/make AVENTAL</code>\n\n"
        "💡 Tip: you can also just type a loco number, or any other text, directly "
        "— no need for the slash commands.",
        parse_mode=ParseMode.HTML,
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await cmd_start(update, context)


async def cmd_loco(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /loco <loco number>, e.g. /loco 32747")
        return
    await loco_lookup(update, context, " ".join(context.args))


async def cmd_make(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /make <text>, e.g. /make AVENTAL")
        return
    await make_lookup(update, context, " ".join(context.args))


async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    if not text:
        return
    if text.isdigit():
        await loco_lookup(update, context, text)
    else:
        await make_lookup(update, context, text)


async def on_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = str(update.effective_chat.id)
    if ADMIN_CHAT_IDS and chat_id not in ADMIN_CHAT_IDS:
        await update.message.reply_text("You're not authorised to update the equipment list.")
        return
    if not ADMIN_CHAT_IDS:
        await update.message.reply_text(
            "Spreadsheet updates are disabled (no ADMIN_CHAT_IDS configured on the server)."
        )
        return

    doc = update.message.document
    if not doc or not doc.file_name.lower().endswith((".xls", ".xlsx")):
        await update.message.reply_text("Please send a .xls or .xlsx equipment list file.")
        return

    await update.message.reply_text("Got it, rebuilding the database, one moment...")
    file = await doc.get_file()
    with tempfile.TemporaryDirectory() as tmp:
        local_path = os.path.join(tmp, doc.file_name)
        await file.download_to_drive(local_path)
        try:
            build_db.build(local_path, DB_PATH)
        except Exception as e:
            log.exception("rebuild failed")
            await update.message.reply_text(f"Rebuild failed: {e}")
            return
    await update.message.reply_text("Database updated successfully.")


def refresh_database_from_excel():
    if not os.path.exists(XLS_PATH):
        raise SystemExit(f"Excel file not found: {XLS_PATH}")
    log.info("Refreshing database from Excel: %s", XLS_PATH)
    try:
        build_db.build(XLS_PATH, DB_PATH)
    except Exception as e:
        log.exception("Excel database refresh failed")
        raise SystemExit(f"Could not rebuild {DB_PATH} from {XLS_PATH}: {e}")
    log.info("Database refresh completed: %s", DB_PATH)


def main():
    if not TOKEN:
        raise SystemExit(
            "Set the TELEGRAM_BOT_TOKEN environment variable before running the bot."
        )
    refresh_database_from_excel()
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("loco", cmd_loco))
    app.add_handler(CommandHandler("make", cmd_make))
    app.add_handler(MessageHandler(filters.Document.ALL, on_document))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))

    log.info("Bot starting...")
    app.run_polling()


if __name__ == "__main__":
    main()
