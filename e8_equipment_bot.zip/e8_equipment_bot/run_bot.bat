@echo off
title E8 Equipment Telegram Bot
echo ==========================================
echo   Starting E8 Equipment Telegram Bot
echo ==========================================
echo.

if "%TELEGRAM_BOT_TOKEN%"=="" (
    echo ERROR: TELEGRAM_BOT_TOKEN is not set.
    echo.
    echo For Command Prompt, run:
    echo   set TELEGRAM_BOT_TOKEN=YOUR_BOT_TOKEN
    echo   set ADMIN_CHAT_IDS=YOUR_CHAT_ID
    echo.
    echo Then run this file again.
    pause
    exit /b 1
)

python bot.py
echo.
echo Bot stopped.
pause
