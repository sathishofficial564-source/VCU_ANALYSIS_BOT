# E8 Section Equipment List — Telegram Bot

Look up loco equipment details (SPM, PG, SR1/SR2, BUR1, BUR2&3, VCU1, VCU2,
RTIS, DPWCS, VCD, FDCS, SIV...) straight from Telegram, sourced from your
`E8_SECTION_EQUIPMENT_LIST_...xls` sheet.

- **Send a loco number** (or `/loco 32747`) → every equipment detail recorded
  for that loco, from both the "3PHASE" and "CONVENTIONAL" sheets.
- **Send a make or any text** (or `/make AVENTAL`) → every loco/field where
  that text appears (make, model, serial number...), across both sheets.

## 1. Files in this package

| File | Purpose |
|---|---|
| `build_db.py` | Parses the source `.xls` into a clean `equipment.db` SQLite file |
| `bot.py` | The Telegram bot itself |
| `requirements.txt` | Python dependencies |
| `equipment.db` | Pre-built database from the file you uploaded (as on 15-05-26) |

## 2. One-time setup

You'll need a small always-on machine (a laptop left running, a cheap VPS,
Raspberry Pi, etc.) since Telegram bots need to stay connected. This can't
run permanently inside this chat — I can only build and test the code here.

1. Install Python 3.10+ and the dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Create your bot: open Telegram, message **@BotFather**, send `/newbot`,
   follow the prompts. It will give you a token that looks like
   `123456789:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`.
3. Set the token as an environment variable:
   ```bash
   export TELEGRAM_BOT_TOKEN="123456789:AAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
   ```
   (On Windows PowerShell: `$env:TELEGRAM_BOT_TOKEN="..."`)
4. (Optional but recommended) Let one or more people update the spreadsheet
   straight from Telegram by messaging the bot a new `.xls` file — find your
   own numeric chat ID by messaging **@userinfobot**, then:
   ```bash
   export ADMIN_CHAT_IDS="111111111,222222222"
   ```
   Leave this unset to disable spreadsheet uploads entirely.

## 3. Run it

```bash
python bot.py
```

Leave this running (use `screen`, `tmux`, `pm2`, a systemd service, or
Task Scheduler, so it survives you closing the terminal). Then open your
bot in Telegram and try:

```
/start
32747
/make AVENTAL
```

## 4. Keeping the data current

The source file is named "AS ON 150526" (15-May-2026) — it's clearly
reissued periodically. Two ways to refresh it:

- **From Telegram** (if `ADMIN_CHAT_IDS` is set): just send the bot the new
  `.xls`/`.xlsx` file as a document. It rebuilds `equipment.db` in place —
  no restart needed.
- **From the command line**:
  ```bash
  python build_db.py "NEW_FILE_NAME.xls" equipment.db
  ```

## 5. Notes on the data

- The source spreadsheet's own column headers are used as the field labels
  shown by the bot (e.g. "SPM-1 Make", "RTIS SL NO", "VCD Age"), so results
  match the layout you already know from Excel.
- `/make` does a case-insensitive substring search across **every** column
  in both sheets, not just "make" columns — handy since a few equipment
  blocks (RTIS, PG, SIV) store the make directly under the equipment's own
  column rather than a separate "Make" column.
- Results are capped (40 locos per `/make` search, and long `/loco` replies
  are split into multiple Telegram messages) to stay within Telegram's
  message-length limits.
