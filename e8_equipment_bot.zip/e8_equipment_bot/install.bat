@echo off
title E8 Equipment Telegram Bot - Install
echo ==========================================
echo   E8 Equipment Telegram Bot - Windows
echo   Installing Python packages...
echo ==========================================
echo.

python --version
if errorlevel 1 (
    echo.
    echo ERROR: Python is not installed or not added to PATH.
    echo Install Python 3.11+ and select "Add Python.exe to PATH".
    pause
    exit /b 1
)

python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo.
echo Installation completed.
pause
