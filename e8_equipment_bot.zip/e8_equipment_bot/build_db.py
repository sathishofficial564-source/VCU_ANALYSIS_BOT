
import sys
import re
import sqlite3
import pandas as pd
from datetime import datetime, date

def clean_value(v):
    if v is None or v is pd.NaT:
        return None
    if isinstance(v, float) and pd.isna(v):
        return None
    if isinstance(v, (pd.Timestamp, datetime, date)):
        try:
            return v.strftime("%d-%b-%Y")
        except Exception:
            return str(v)
    s = str(v).strip()
    if not s or s.lower() in ("nan", "nat"):
        return None
    if re.fullmatch(r"-?\d+\.0", s):
        s = s[:-2]
    return s

def sanitize_col(name):
    s = re.sub(r"[^0-9A-Za-z]+", "_", str(name)).strip("_")
    if not s:
        s = "col"
    if s[0].isdigit():
        s = "c_" + s
    return s

def unique_names(labels):
    seen = {}
    out = []
    for label in labels:
        base = sanitize_col(label)
        n = seen.get(base.lower(), 0) + 1
        seen[base.lower()] = n
        out.append(base if n == 1 else f"{base}_{n}")
    return out

def build_3phase(df):
    # Find the row containing LOCO NO. In your sheet this is the equipment
    # header row, followed by a sub-header row.
    header_row = None
    for r in range(min(10, len(df))):
        vals = [str(x).strip().upper() if pd.notna(x) else "" for x in df.iloc[r]]
        if "LOCO NO" in vals:
            header_row = r
            break
    if header_row is None:
        raise ValueError("Could not find 'LOCO NO' in 3PHASE sheet.")
    sub_row = header_row + 1
    top = df.iloc[header_row]
    sub = df.iloc[sub_row]

    labels = []
    current_group = None
    for c in range(df.shape[1]):
        t = clean_value(top.iloc[c])
        s = clean_value(sub.iloc[c])
        if t:
            u = t.upper()
            if u in ("S.NO", "S.NO.", "S_NO", "LOCO NO", "LOCO_NO", "TYPE"):
                current_group = None
                labels.append("LOCO NO" if u.startswith("LOCO") else t)
            else:
                current_group = t
                labels.append(f"{t} {s}" if s else t)
        else:
            labels.append(f"{current_group} {s}" if current_group and s else (s or f"Column_{c+1}"))
    names = unique_names(labels)

    rows = []
    for r in range(sub_row + 1, len(df)):
        vals = [clean_value(df.iat[r,c]) for c in range(df.shape[1])]
        if not any(v is not None for v in vals):
            continue
        row = dict(zip(names, vals))
        loco_key = names[next(i for i,l in enumerate(labels) if l == "LOCO NO")]
        if row.get(loco_key):
            rows.append(row)
    return names, labels, rows

def build_conventional(df):
    # Actual CONV sheet layout from E8 QUIPMENTS LIST AS ON 170826.xls:
    # col 0 = S.NO., col 1 = Loco No
    # SPM: cols 2-6 (MAKE, RECORDER, MFG, S.NO, Age)
    # SPM-2: cols 7-10 (INDICATOR, MFG, S.NO, Age)
    # VCD: cols 11-14 (MAKE, Mfg, S.No, Age)
    # MPCS: cols 15-18 (MAKE, MFY, S NO, AGE)
    # SIV: cols 19-22 (MAKE, MFY, SL NO, AGE)
    # RTIS: cols 23-25 (MAKE, SL NO, MFY)
    # PG: cols 26-27 (SL, MFY)
    group_row = df.iloc[0]
    field_row = df.iloc[1]

    labels = [None] * df.shape[1]
    labels[0] = "S.NO."
    labels[1] = "LOCO NO"

    groups = [
        ("SPM-1", 2, 7),
        ("SPM-2", 7, 11),
        ("VCD", 11, 15),
        ("MPCS", 15, 19),
        ("SIV", 19, 23),
        ("RTIS", 23, 26),
        ("PG", 26, 28),
    ]
    for group, start, end in groups:
        for c in range(start, min(end, df.shape[1])):
            f = clean_value(field_row.iloc[c])
            labels[c] = f"{group} {f}" if f else f"{group} Field_{c-start+1}"

    names = unique_names(labels)
    rows = []
    for r in range(2, len(df)):
        vals = [clean_value(df.iat[r, c]) for c in range(df.shape[1])]
        if not any(v is not None for v in vals):
            continue
        row = dict(zip(names, vals))
        if row.get(names[1]):
            rows.append(row)
    return names, labels, rows

def write_table(conn, table_name, names, labels, rows):
    cur = conn.cursor()
    cur.execute(f'DROP TABLE IF EXISTS "{table_name}"')
    defs = ", ".join(f'"{n}" TEXT' for n in names)
    cur.execute(f'CREATE TABLE "{table_name}" ({defs})')
    if rows:
        placeholders = ", ".join("?" for _ in names)
        cols = ", ".join(f'"{n}"' for n in names)
        sql = f'INSERT INTO "{table_name}" ({cols}) VALUES ({placeholders})'
        cur.executemany(sql, [[row.get(n) for n in names] for row in rows])

    cur.execute("DELETE FROM column_labels WHERE table_name=?", (table_name,))
    for i, (n, label) in enumerate(zip(names, labels)):
        cur.execute(
            "INSERT INTO column_labels(table_name,column_name,display_label,col_order) VALUES(?,?,?,?)",
            (table_name, n, label, i)
        )
    conn.commit()

def build(xls_path, db_path):
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS column_labels(
            table_name TEXT,
            column_name TEXT,
            display_label TEXT,
            col_order INTEGER
        )
    """)

    xls = pd.ExcelFile(xls_path)

    if "3PHASE" in xls.sheet_names:
        df = pd.read_excel(xls_path, sheet_name="3PHASE", header=None)
        names, labels, rows = build_3phase(df)
        write_table(conn, "3PHASE", names, labels, rows)
        print(f"3PHASE: {len(rows)} loco rows, {len(names)} columns")
        print("3PHASE loco column:", names[labels.index("LOCO NO")])
    else:
        print("WARNING: sheet '3PHASE' not found, skipping")

    conv = next((s for s in xls.sheet_names if s.strip().upper() in ("CONV", "CONVENTIONAL")), None)
    if conv:
        df = pd.read_excel(xls_path, sheet_name=conv, header=None)
        names, labels, rows = build_conventional(df)
        write_table(conn, "CONVENTIONAL", names, labels, rows)
        print(f"CONVENTIONAL: {len(rows)} loco rows, {len(names)} columns")
    else:
        print("WARNING: sheet 'CONV/CONVENTIONAL' not found, skipping")

    conn.close()
    print("Done.")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print('Usage: python build_db.py "<source.xls>" <output.db>')
        sys.exit(1)
    build(sys.argv[1], sys.argv[2])
