@echo off
title E8 Equipment Telegram Bot - Build Database
echo ==========================================
echo   Building E8 equipment database
echo ==========================================
echo.

set "EXCEL_FILE=E8 QUIPMENTS LIST AS ON 170826.xls"

if not exist "%EXCEL_FILE%" (
    echo ERROR: Excel file not found:
    echo %EXCEL_FILE%
    pause
    exit /b 1
)

python build_db.py "%EXCEL_FILE%" equipment.db

echo.
echo Database build command completed.
pause
